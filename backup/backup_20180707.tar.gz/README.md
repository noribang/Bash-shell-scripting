# Bash-shell-scripting
Notes on Bash shell scripting.
