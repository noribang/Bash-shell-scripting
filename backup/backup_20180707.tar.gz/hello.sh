#!/bin/bash
# declare STRING variable
STRING="HEEELOOO WorldDDDDDDD"
#print variable on screen
echo $STRING